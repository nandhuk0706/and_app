<?php
$dbcon=mysqli_connect("localhost","id4174600_localhost","test@1234") or die("Could not Connect My Sql");
mysqli_select_db($dbcon,"id4174600_product_delatil")  or die("Could connect to Database");
?>
